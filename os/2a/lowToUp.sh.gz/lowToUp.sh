#!/bin/usr/env/bash

for name in $@
do
	echo "File Name: $name"
	tr '[:lower:]' '[:upper:]' < $name
	echo " "
done

