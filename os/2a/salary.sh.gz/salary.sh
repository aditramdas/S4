#!/bin/usr/env/bash

echo "Enter the basic salary: "
read base
if [ $base -lt 1500 ]
then
	hra=$(($base*10/100))
	da=$(($base*90/100))
else
	hra=500
	da=$(($base*98/100))
fi
gross=$((hra+da+base))
echo "Gross salary is:" $gross
