#!/bin/usr/env/bash

echo "Number of arguments: $#"
i=$#
echo -n "Arguments in reverse order: "
while [ $i -ge 1 ]
do
	echo -n ${!i} ""
	i=$(($i-1))
done
echo " "