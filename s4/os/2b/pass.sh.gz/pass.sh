#!/bin/usr/env/bash

echo -n "Input String: "
read a
len=${#a}
if [ $len -ge 8 ]
then
	if [[ $a=~[A-Z] ]]
	then
		if [[ $a=~[a-z] ]]
		then
			if [[ $a=~[0-9] ]]
			then
				if [[ $a=~"_" ]]
				then
					echo "Strong Password"
				else
					echo "Weak Password"
				fi
			else
				echo "Weak Password"
			fi
		else
			echo "Weak Password"
		fi
	else
		echo "Weak Password"
	fi
else
	echo "Weak Password"
fi