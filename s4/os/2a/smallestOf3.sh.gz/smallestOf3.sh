#!/bin/usr/env/bash

echo -n "First input: "
read a
echo -n "Second input: "
read b
echo -n "Third input: "
read c
if [ $a -lt $b ]
then
	if [ $a -lt $c ]
	then
		echo "Smallest is the $a"
	else
		echo "Smallest is the $c"
	fi
else
	if [ $b -lt $c ]
	then
		echo "Smallest is the $b"
	else
		echo "Smallest is the $c"
	fi
fi
