#!/bin/usr/env/bash

echo -n "Number: "
read a
i=1
while [ $i -le $a ]
do
	j=1
	while [ $j -le $i ]
	do
		echo -n $i
		j=$((j+1))
	done
	echo ""
	i=$((i+1))
done