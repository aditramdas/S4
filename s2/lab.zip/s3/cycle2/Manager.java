public class Manager extends Employee{
	String dept;
}