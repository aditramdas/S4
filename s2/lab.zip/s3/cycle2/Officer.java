public class Officer extends Employee{
	String specialization;
}