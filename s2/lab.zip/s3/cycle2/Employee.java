public class Employee{
	String name;
	int age;
	double phone;
	String address;
	static double salary;
	public static void printSalary(){
		System.out.print("Salary : " +salary);
	}
}