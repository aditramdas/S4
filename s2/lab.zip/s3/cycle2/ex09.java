import java.util.*;

public class ex09{
	public static void main(String args[])
	{
		
	}
}