import java.util.*;

public class ex03{
	public static void main(String args[]){
		Engineer e1 = new Engineer();
		e1.display();
		e1.calcSalary();
	}
}