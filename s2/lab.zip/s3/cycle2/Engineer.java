public class Engineer extends Employee1{
	static double salary;
	public static void calcSalary(){
		System.out.println("Salary of employee: 20000" );
	}
}