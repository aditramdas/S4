public class Employee1{
	public static void display() 
		{
			System.out.println("Name of the class is Employee");
	}
	
	public static void calcSalary(double salary){
		System.out.println("Salary of employee: 10000" );
	}
}